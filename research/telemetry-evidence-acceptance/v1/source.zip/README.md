# Acceptance Before Export: A Bounded Evidence Contract for Governance Telemetry

Technical report, version 1, September 27, 2026. Not peer reviewed. Patent Pending.

Build: `cd telemetry-evidence-acceptance && tectonic paper.tex` (prepared with Tectonic 0.16.9).
The fonts and their OFL licenses are in `_paper-assets/fonts/`, the same relative path the
manuscript uses in agentrust-io/papers.

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/agentrust-telemetry.

This package contains the manuscript source, the experiment scripts and the record of the
September 27 rerun. It is not an independent replication.

The evaluated code is agentrust-telemetry commit 29c13cfa4047a0f5784a90df63b22a3568453158
(0.1.0-alpha.2). `telemetry-evidence-acceptance/experiments/results/rerun-2026-09-27/pinned/` records that rerun: 111
Python unit tests passed and all 13 portable fixtures produced their expected verdicts, the
same as on September 4. `later-revision/` repeats the four boundary probes at a later main
commit, listed in `COMMITS.txt`, with the same outcomes. The TypeScript suite was not run.
No durable store, crash-restart, multi-process or deployed-exporter experiment was run.

The September 4 records are not included because they contain local paths.

Current implementation guidance: https://agentrust-io.com/telemetry/
