# TRACE: Trust, Runtime Attestation, and Compliance Evidence (A Portable Attestation Format for AI Agent Runtime Governance)

Technical report, version 1, September 27, 2026. Not peer reviewed.

Build: `tectonic paper.tex` (prepared with Tectonic 0.16.9).

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/trace-spec.

This package contains the manuscript source, figures, and recorded experiment
material present with that manuscript. Results were not rerun for this edition.
It is not an independently replicated or fully pinned reproduction package.
Current implementation guidance: https://trace.agentrust-io.com/

The manuscript's June 23 date is a drafting date. Saved TRACE and Agent Manifest
measurements include July 1 runs. Do not treat it as a verified publication date.

Historical dependencies: agentrust-trace==0.2.0 and trace-tests==0.2.0. Set TRACE_VECTORS_DIR to the historical vector checkout. Do not run against current vectors and label the output a reproduction of the saved run.
