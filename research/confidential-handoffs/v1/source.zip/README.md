# Confidentiality Across Agent Handoffs: source package, version 1

Technical report, version 1, September 27, 2026. Imran Siddique, OPAQUE Systems.
The PDF is published separately at
https://agentrust-io.com/research/confidential-handoffs/v1/paper.pdf.

## Contents

- `paper.md`: manuscript source. `build_paper.py` rebuilds the PDF with
  ReportLab and PyMuPDF: `python build_paper.py --source . --output paper.pdf`.
  It reads Times New Roman and Arial TrueType files from `--fonts`
  (default `C:/Windows/Fonts`); fonts are not bundled.
- `experiments/rerun-2026-09-27.txt`: the rerun record for section 8.
- `experiments/reference-2026-09-19/`: minimized evidence from the recorded
  run (WCM tested merge 15e67c2, GitHub Actions run 35469947313).
- `experiments/rerun-2026-09-27/`: minimized evidence from the rerun at WCM
  main 94d5519 (hosted run 36272971255 and its fresh bundle reproduction) and
  from a local fresh-environment run on Windows.
- `experiments/compare_observations.py`: compares observation records across
  runs after removing transaction identifiers and container image digests.
- `launcher/composed-reproduction.zip`: the WCM reproduction launcher built by
  hosted run 36272971255 (SHA-256
  a209faca6139cd3c02b554edae0d9702af4f1932ae19fca939ce4e4229829ef4), with its
  Apache-2.0 LICENSE and NOTICE.
- `manifest.json`: SHA-256 of every other file in this package.

## Reproduce

Extract `launcher/composed-reproduction.zip` and run
`python reproduce.py --workspace <new directory>` with Python 3.12, Git and
network access to GitHub and PyPI. The portable profile runs 32 cases. Add
`--confined` on native Linux with Docker for all 36. Then compare:

    python experiments/compare_observations.py \
        experiments/reference-2026-09-19/observations.jsonl \
        <new directory>/evidence/observations.jsonl

## Limits

Attestation is synthetic, signed by test-owned roots. One operator runs every
party. The diagnostic model computes 3 * 7 + 2 on the trusted host. No hardware
protects the model key or computation, and no GPU path is exercised. Hardware
acceptance and independently operated peers are future work. The GCP and Azure
hardware diagnostics summarized in section 7 are not reproducible from this
package; their raw captures contain device-identifying data and are not
included. SHA-256 values detect changes relative to `manifest.json`; they do
not authenticate the publisher.
