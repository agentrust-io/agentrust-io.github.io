# Licenses

- `paper.md`, `experiments/` text and data, `build_paper.py` and
  `experiments/compare_observations.py`: Creative Commons Attribution 4.0
  International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/,
  as stated for agentrust-io papers in the papers repository.
- `launcher/composed-reproduction.zip`: Apache License 2.0, from
  agentrust-io/weight-custody-manifest. The license text and NOTICE are in
  `launcher/LICENSE` and `launcher/NOTICE` and inside the ZIP.
- Source fetched by the launcher (WCM, cMCP, cA2A) is governed by the license
  in each repository at the pinned revision.

Patent Pending.
