# From Agent Observability to Governance Evidence: A Privacy-Constrained Telemetry Contract

Technical report, version 1, September 27, 2026. Not peer reviewed.

Build: `tectonic paper.tex` (prepared with Tectonic 0.16.9).

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/agentrust-telemetry.

This package contains the manuscript source and the record of the software rerun made for
this edition. It is not an independently replicated or fully pinned reproduction package.
Current implementation guidance: https://agentrust-io.com/telemetry/

The evaluated code is agentrust-telemetry 0.1.0-alpha.2, commit
29c13cfa4047a0f5784a90df63b22a3568453158. experiments/results/rerun-2026-09-27.txt records
the September 27 rerun at that commit: 111 Python unit tests passed and all 13 portable
fixtures produced their expected verdicts, with agentrust-trace pinned to 0.9.0 as on
September 3. With agentrust-trace 0.11.0 one test fails; the report explains why. The
TypeScript suite was not rerun.
