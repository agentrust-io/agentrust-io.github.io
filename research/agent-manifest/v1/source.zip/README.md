# Agent Manifest: Portable, Hardware-Attestable Identity and Provenance for AI Agents

Technical report, version 1, September 27, 2026. Not peer reviewed.

Build: `tectonic paper.tex` (prepared with Tectonic 0.16.9).

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/agent-manifest.

This package contains the manuscript source, figures, and recorded experiment
material present with that manuscript. Results were not rerun for this edition.
It is not an independently replicated or fully pinned reproduction package.
Current implementation guidance: https://manifest.agentrust-io.com/

The manuscript's June 23 date is a drafting date. Saved TRACE and Agent Manifest
measurements include July 1 runs. Do not treat it as a verified publication date.

Set AGENT_MANIFEST_ROOT to an SDK checkout containing python/src and examples. The saved run did not capture its exact SDK commit; that provenance limitation remains.
