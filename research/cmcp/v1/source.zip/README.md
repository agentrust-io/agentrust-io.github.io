# cMCP: Verifiable Policy Enforcement for AI Agent Tool Calls

Technical report, version 1, September 27, 2026. Not peer reviewed.

Build: `tectonic paper.tex` (prepared with Tectonic 0.16.9).

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/cmcp.

This package contains the manuscript source, figures, and recorded experiment
material present with that manuscript. Results were not rerun for this edition.
It is not an independently replicated or fully pinned reproduction package.
Current implementation guidance: https://cmcp.agentrust-io.com/

The manuscript's June 23 date is a drafting date. Saved TRACE and Agent Manifest
measurements include July 1 runs. Do not treat it as a verified publication date.

Experiment runners referenced by the manuscript live in the cMCP project. The manuscript does not pin their exact source revision; current results may differ.
