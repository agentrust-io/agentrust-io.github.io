# cA2A: Confidential Agent-to-Agent Delegation as a Profile on A2A

Technical report, version 2, October 1, 2026. Not peer reviewed. Patent Pending.
Version 2 corrects the cross-workflow splice claim in Section 3 and Property C2 and adds three
citations; results are unchanged.

Build: `tectonic paper.tex` (prepared with Tectonic 0.16.9; set SOURCE_DATE_EPOCH=1790812800
to reproduce the published PDF byte for byte).

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/ca2a.

This package contains the manuscript source, figures, the three scale and cost experiment
scripts, their results, and the record of the software rerun made for this edition. It is not
an independently replicated or fully pinned reproduction package.
Current implementation guidance: https://ca2a.agentrust-io.com/

The evaluated code is ca2a 0.3.1, tag v0.3.1, commit 7d90823142dda1be589def3b22a3099581c7df7a.
experiments/results/rerun-2026-09-27.txt records the September 27 rerun at that commit: the
report's three experiments, the repository's six per-claim experiments, and the project's
test suite (779 passed, 11 skipped), plus offline appraisal of one public GCP Intel TDX quote.
Run the scripts with CA2A_ROOT set to a ca2a checkout at that tag.

experiments/results/original-2026-07-01/ keeps the July 2026 results unchanged. They were
produced against an unpinned ca2a checkout of that date. Correctness counts match the rerun;
timings differ (see the report's Table 3).

No hardware run was repeated for this edition, and no hardware evidence is included. The
hardware runs the report describes are recorded in the ca2a repository under
experiments/hardware-validation/ and docs/hardware-validation.md.
