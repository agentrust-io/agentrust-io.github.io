# Weight Custody Manifest: Portable, Attestation-Gated Custody for Proprietary Model Weights

Technical report, version 1, September 27, 2026. Not peer reviewed.

Build: `tectonic paper.tex` (prepared with Tectonic 0.16.9).

Paper text is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Project code retains its existing project license; see https://github.com/agentrust-io/weight-custody-manifest.

This package contains the manuscript source and the record of the software rerun
made for this edition. It is not an independently replicated or fully pinned
reproduction package.
Current implementation guidance: https://wcm.agentrust-io.com/

The evaluated code is commit 2acedfa883204f7d1fd457d3ee603198d85be82c (WCM 0.28.0).
experiments/results/rerun-2026-09-27.txt records the September 27 rerun at that
commit: 618 passed, 3 skipped, and the reference conformance self-test at 91 of 91
vectors. Dependencies were resolved on the rerun date, not pinned to September 3.
The SEV-SNP hardware runs described in the report were not repeated, and their
captured receipts are not included in this package.

Versions up to 0.28.2, including the evaluated version, are affected by
GHSA-j665-99rh-w85h (GPU confidential-compute mode not required for key release).
Use a patched release for any deployment.
